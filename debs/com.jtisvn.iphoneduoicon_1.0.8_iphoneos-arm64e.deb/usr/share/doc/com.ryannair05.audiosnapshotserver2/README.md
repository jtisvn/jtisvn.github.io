# AudioSnapshotServer2

AudioSnapshotServer2 is a capture and analysis service used by
Mitsuha Six on iOS 15 and newer. In Lunora beta6 it selects `mediaserverd` or `audiomxd` using the system
`audiomxd_enabled` query (legacy fallback: `mediaserverd`), captures one
observed output mix, reduces the audio to waveform and spectrum features, and
sends those features to local clients.

- Transport is UDP on `127.0.0.1:44333`; multicast is not used.
- Raw PCM never leaves `mediaserverd`.
- Clients are expected to refresh a lightweight lease every five seconds; the
  server expires a client after fifteen seconds without a refresh.
- Feature datagrams use the fixed little-endian `MSH2` protocol.
- Capture and FFT work stop when there are no subscribers.

The captured stream is a system mix, not an isolated application stream.
Concurrent media, alerts, and system sounds can therefore appear together.

## Building

```sh
make package
```

Host-side protocol validation is available separately:

```sh
make -C Tests test
```
