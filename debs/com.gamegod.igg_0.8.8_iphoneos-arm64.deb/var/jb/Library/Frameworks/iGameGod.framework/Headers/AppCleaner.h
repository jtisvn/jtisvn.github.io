#ifndef AppCleaner_h
#define AppCleaner_h

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

void IGGAppCleanerWipeAppData(void);
void IGGAppCleanerMarkSpoofedIDsForNextLaunchReset(void);
void IGGAppCleanerResetSpoofedIDsOnNextLaunchIfNeeded(void);
void IGGAppCleanerRunPendingWipeOnLaunchIfNeeded(void);
void IGGAppCleanerInstallLifecycleCleanupObservers(void);
void IGGAppCleanerInstallSpoofHooks(void);

NS_ASSUME_NONNULL_END

#endif /* AppCleaner_h */
