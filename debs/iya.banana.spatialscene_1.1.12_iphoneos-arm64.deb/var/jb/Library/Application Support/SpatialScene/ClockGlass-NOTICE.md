# Clock glass renderer provenance

Backend and Shared files are adapted from winaviation-tweaks/liquidass,
upstream commit 9b7c5eb813dabf7ea3afb940767930e128fca775.
Source: https://github.com/winaviation-tweaks/liquidass
License: CC BY-NC 4.0; see LICENSE. Preserve attribution and noncommercial terms.

SpatialScene modifications: separate filter names, file/notification namespace,
clock-only host registry, lazy opt-in activation, readiness status, and removal
of the upstream accessibility-file cleanup. This is an independent bundled
renderer, not a dependency on the installed LiquidAss package. Original shader
refraction and private QuartzCore symbol/ABI resolution are retained for device
validation. SpatialScene additionally implements glyph-only bevel lighting,
inner shading and transmission softening; see GLASS_MATERIAL_REFERENCE.md in
the source repository for the separate read-only material-reference study.
